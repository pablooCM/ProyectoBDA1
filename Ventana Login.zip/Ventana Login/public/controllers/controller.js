var myApp = angular.module('myApp', []);
myApp.controller('AppCtrl',['$scope','$http', function($scope, $http){
	console.log("Hello World from controller");

$scope.login = function(){
	if($scope.student.email == "admin" && $scope.student.pass == "pass"){
		window.alert("Exito al entrar a su cuenta de administrador");
		// Mostrar ventana de admin			
	}
	else{
		$http.get('/estudiante/'+ $scope.student.email).then(function(response, err) {
			if(!err){
				if(response.data == null){
					window.alert("Favor revisar datos");
				}
				else{
					console.log("Hola gatitos");
						if ($scope.student.pass == response.data.pass){
							window.alert("Exito al entrar a su cuenta");
						}
						else{
							window.alert("Contraseña incorrecta");
							console.log("ENTRE AL ELSE");
						}
					}
			}
			else{
				window.alert("Error en la conexion");
			}
		});
	}
};

}])
