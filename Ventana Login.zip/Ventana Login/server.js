var express = require('express');
var app = express();
var mongojs = require('mongojs');
var db = mongojs('estudiante', ['estudiante']);
var bodyParser = require('body-parser');

app.use(express.static( __dirname + "/public"));
app.use(bodyParser.json());

app.post('/estudiante',function(req,res){
	console.log(req.body);
	db.estudiante.insert(req.body, function (err, doc){
		res.json(doc);
	})
})

app.get('/estudiante/:email', function(req, res){
	var email = req.params.email;
	console.log("HUEHUEHEUEHEUEHUE");
	console.log(email);
	db.estudiante.findOne({email : email}, function(err,doc){
		console.log("DOC " + doc);
		res.json(doc);
	});
});

app.get('/manager/:email/:pass', function(req, res){
	var email = req.params.email;
	var pass = req.params.pass;
	db.auth({user: email,pwd: pass}, function(err,doc){
		console.log("ADMIN DOC " + doc);
	});
})

app.listen(4000);
console.log("Server runing on port 4000");